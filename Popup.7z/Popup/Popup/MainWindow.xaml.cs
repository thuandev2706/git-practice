﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Popup
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isEnteredButton = false;
        private bool isEnteredPopup = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            ppMenu.PlacementTarget = sender as FrameworkElement;
            ppMenu.VerticalOffset = 10;
            ppMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Top;
            ppMenu.IsOpen = true;
            isEnteredButton = true;
        }

        private void Button_MouseMove(object sender, MouseEventArgs e)
        {
            var btn = sender as Button;
            Point p = e.GetPosition(btn);
            Rect rect = new Rect(0, 0, btn.ActualWidth, btn.ActualHeight);
            if (!rect.Contains(p))
            {
                isEnteredButton = false;                
            }
            if (!isEnteredButton && !isEnteredPopup)
            {
                ppMenu.IsOpen = false;
            }
        }

        private void StackPanel_MouseEnter(object sender, MouseEventArgs e)
        {
            isEnteredPopup = true;
        }

        private void StackPanel_MouseLeave(object sender, MouseEventArgs e)
        {
            isEnteredPopup = false;
            ppMenu.IsOpen = false;
        }

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            var btn = sender as Button;
            Point p = e.GetPosition(btn);
            Rect rect = new Rect(0, 0, btn.ActualWidth, btn.ActualHeight);
            if (!rect.Contains(p))
            {
                isEnteredButton = false;
            }
            if (!isEnteredButton && !isEnteredPopup)
            {
                ppMenu.IsOpen = false;
            }
        }
    }
}
