// eslint-disable-next-line import/no-extraneous-dependencies
import { REBRANDED_QLIK_ICON } from '@talend/app-switcher/lib/AppSwitcher.constants';

window.APP.appSwitcherHelper = {
  REBRANDED_QLIK_ICON,
};
