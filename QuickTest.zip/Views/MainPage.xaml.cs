﻿using System.Diagnostics;
using Microsoft.UI.Xaml.Controls;

using QuickTest.ViewModels;

namespace QuickTest.Views;

public sealed partial class MainPage : Page
{
    public MainViewModel ViewModel
    {
        get;
        set;
    }

    public MainPage()
    {
        ViewModel = App.GetService<MainViewModel>();
        InitializeComponent();
        dpk.MinDate = DateTimeOffset.Now;
        dpk.Date = DateTimeOffset.Now;
    }

    private void dpk_DateChanged(CalendarDatePicker sender, CalendarDatePickerDateChangedEventArgs args)
    {
        ViewModel.EndDate = dpk.Date.Value.DateTime;
        ViewModel.CreateEndtimeOpt();
    }
}
