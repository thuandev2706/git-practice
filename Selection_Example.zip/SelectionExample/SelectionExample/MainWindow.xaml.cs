﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace SelectionExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public sealed partial class MainWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();
            this.rootElement.DataContext = CreateDataSource();
        }

        private static object CreateDataSource()
        {
            var items = new List<string>();
            for (int i = 1; i < 50; i++)
            {
                items.Add("Item " + i);
            }
            return items;
        }
    }
}
