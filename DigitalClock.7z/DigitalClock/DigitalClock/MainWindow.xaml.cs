﻿using CefSharp;
using CefSharp.SchemeHandler;
using CefSharp.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DigitalClock
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ChromiumWebBrowser browser;
        private bool isFullScreen = false;
        public MainWindow()
        {
            InitializeComponent();
            InitBrowser();
        }

        public void InitBrowser()
        {
            var settings = new CefSettings();

            settings.RegisterScheme(new CefCustomScheme
            {
                SchemeName = "localfolder",
                DomainName = "cefsharp",
                SchemeHandlerFactory = new FolderSchemeHandlerFactory(
                    rootFolder: @".\WebPage",
                    hostName: "cefsharp",
                    defaultPage: "index.html" // will default to index.html
                )
            });

            Cef.Initialize(settings);

            browser = new ChromiumWebBrowser("localfolder://cefsharp/");
            browserPanel.Children.Add(browser);
        }                

        private void windowBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void minBtn_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void maxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!isFullScreen)
            {
                this.WindowState = WindowState.Maximized;
                iconMax.Kind = MaterialDesignThemes.Wpf.PackIconKind.WindowRestore;
            }
            else
            {
                this.WindowState = WindowState.Normal;
                iconMax.Kind = MaterialDesignThemes.Wpf.PackIconKind.WindowMaximize;                
            }
            isFullScreen = !isFullScreen;
        }

        private void closeBtn_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }       
    }
}
