﻿using System.Diagnostics;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media.Imaging;
using QuickTest.ViewModels;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage.Streams;
using Windows.Storage;

namespace QuickTest.Views;

public sealed partial class MainPage : Page
{
    public MainViewModel ViewModel
    {
        get;
        set;
    }

    public MainPage()
    {
        ViewModel = App.GetService<MainViewModel>();
        InitializeComponent();
    }
    private void Grid_DragOver(object sender, DragEventArgs e)
    {
        e.AcceptedOperation = DataPackageOperation.Copy;
        e.DragUIOverride.Caption = "Drop files here";
        e.DragUIOverride.IsCaptionVisible = true;
        //if (e.DataView.Contains(StandardDataFormats.StorageItems))
        //{
        //    var items = await e.DataView.GetStorageItemsAsync();
        //    if (items.Count > 0 && items[0] is StorageFile file)
        //    {
        //        Check if the file is an image (you can add more file type checks here)
        //        if (file.ContentType.StartsWith("image/"))
        //        {
        //            e.AcceptedOperation = DataPackageOperation.Copy;

        //        }
        //    }
        //}
    }

    private async void Grid_Drop(object sender, DragEventArgs e)
    {
        if (e.DataView.Contains(StandardDataFormats.StorageItems))
        {
            var items = await e.DataView.GetStorageItemsAsync();
            if (items.Count > 0 && items[0] is StorageFile file)
            {
                // Load the image from the file
                var bitmapImage = new BitmapImage();
                using (IRandomAccessStream stream = await file.OpenReadAsync())
                {
                    bitmapImage.SetSource(stream);
                }
                myImg.Source = bitmapImage;
            }
        }
        //// Retrieve the dropped files
        //var items = await e.DataView.GetStorageItemsAsync();

        //// Process each dropped file
        //foreach (var item in items)
        //{
        //    // Perform actions with the dropped file, such as displaying or saving
        //    // For demonstration purposes, let's just print the file name
        //    if (item is Windows.Storage.StorageFile file)
        //    {
        //        Debug.WriteLine($"Dropped file: {file.Name}");
        //        StorageFile imageFile = await StorageFile.GetFileFromApplicationUriAsync(new Uri(item.Path));
        //        //Create a bitmap image from the image file
        //        using (IRandomAccessStream fileStream = await imageFile.OpenAsync(FileAccessMode.Read))
        //        {
        //            BitmapImage bitmapImage = new BitmapImage();
        //            await bitmapImage.SetSourceAsync(fileStream);

        //            // Set the Image control's Source property to the bitmap image
        //            myImg.Source = bitmapImage;
        //        }
        //    }
        //}
    }
}
