﻿namespace QuickTest.Contracts.Services;

public interface IPageService
{
    Type GetPageType(string key);
}
