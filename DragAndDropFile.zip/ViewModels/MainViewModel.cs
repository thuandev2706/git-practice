﻿using System.Collections.ObjectModel;
using System.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using QuickTest.Models;

namespace QuickTest.ViewModels;

public partial class MainViewModel : ObservableRecipient
{
    [ObservableProperty] private ObservableCollection<PollOption> pollOptions;
    [ObservableProperty] private ObservableCollection<string> endtimeOptions;
     public DateTime EndDate = DateTime.Today;
    [ObservableProperty] private string endTime = string.Empty;
    public MainViewModel()
    {
        PollOptions = new ObservableCollection<PollOption>() { new PollOption(), new PollOption()};
        EndtimeOptions = new ObservableCollection<string>();
    }

    public void CreateEndtimeOpt()
    {
        int startH = 0;
        if (EndDate.ToString("yyyyMMdd") == DateTime.Now.ToString("yyyyMMdd"))
        {
            startH = DateTime.Now.Hour + 1;
        }

        EndtimeOptions.Clear();
        for (int i = startH; i <= 23; i++)
        {
            EndtimeOptions.Add($"{i.ToString("D2")}:00");
        }
        EndTime = EndtimeOptions[0];
    }

    [RelayCommand]
    public void GetTime()
    {
        Debug.WriteLine($"{EndDate}-{EndTime}");
        var arrTime = EndTime.Split(':');
        var output = new DateTime(EndDate.Year, EndDate.Month, EndDate.Day, int.Parse(arrTime[0]), 0, 0);
        Debug.WriteLine(output.ToString("yyyy-MM-dd HH:mm"));
        Debug.WriteLine(output.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
    }
}
